// ═══════════════════════════════════════════════════════════════
//  SAUERTEIG PLANER — Flutter App
//  lib/main.dart
//
//  Einstiegspunkt der App. Hier wird alles gestartet.
// ═══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:math';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

// ── Benachrichtigungen global initialisieren ──────────────────
final FlutterLocalNotificationsPlugin notifications =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Benachrichtigungen initialisieren
  const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
  const initSettings = InitializationSettings(android: androidSettings);
  await notifications.initialize(initSettings);

  runApp(const SauerteigApp());
}

// ═══════════════════════════════════════════════════════════════
//  APP ROOT
// ═══════════════════════════════════════════════════════════════
class SauerteigApp extends StatelessWidget {
  const SauerteigApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sauerteig Planer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFFD4A84B), // Gold
        scaffoldBackgroundColor: const Color(0xFF0F0E0C),
        cardColor: const Color(0xFF1A1814),
        fontFamily: 'Roboto',
      ),
      home: const PlanerScreen(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  FARBEN (Konstanten)
// ═══════════════════════════════════════════════════════════════
class AppColors {
  static const bg       = Color(0xFF0F0E0C);
  static const surface  = Color(0xFF1A1814);
  static const surface2 = Color(0xFF242018);
  static const surface3 = Color(0xFF2E2A20);
  static const gold     = Color(0xFFD4A84B);
  static const gold2    = Color(0xFFE8C97A);
  static const goldDim  = Color(0xFF7A6030);
  static const text     = Color(0xFFF0ECE0);
  static const text2    = Color(0xFFB8B09A);
  static const text3    = Color(0xFF7A7260);
  static const green    = Color(0xFF6DB87A);
  static const blue     = Color(0xFF6AABD4);
  static const orange   = Color(0xFFD4804B);
  static const red      = Color(0xFFD45050);
  static const border   = Color(0xFF2A2620);
}

// ═══════════════════════════════════════════════════════════════
//  BERECHNUNGS-LOGIK
// ═══════════════════════════════════════════════════════════════

/// Berechnet Faktor f aus Zielzeit und Temperatur
/// Modell: t_22 = 5 × f^0.623  (an bekannte Datenpunkte angepasst)
double factorFromTime(double targetH, double temp) {
  final t22 = targetH / pow(2, (22 - temp) / 8);
  return pow(t22 / 5.0, 1 / 0.623).toDouble();
}

/// Berechnet geschätzte Zeit für Faktor f und Temperatur
double timeFromFactor(double f, double temp) {
  final t22 = 5.0 * pow(f, 0.623);
  return t22 * pow(2, (22 - temp) / 8);
}

/// Findet den besten (sinnvoll gerundeten) Faktor für Zielzeit + Temp
Map<String, dynamic> pickBestFactor(double targetH, double temp) {
  final fExact = factorFromTime(targetH, temp).clamp(0.5, 50.0);

  // Auf sinnvolle ganze Zahl runden
  double fRounded;
  if (fExact <= 1.3) {
    fRounded = 1.0;
  } else if (fExact <= 1.7) {
    fRounded = 1.5;
  } else {
    fRounded = fExact.round().toDouble();
  }

  // Nachbarn prüfen, besten wählen
  final candidates = {
    fExact.floor().toDouble(),
    fExact.ceil().toDouble(),
    fRounded,
  }.where((v) => v >= 1).toList();

  double best = fRounded;
  double bestDiff = double.infinity;
  for (final c in candidates) {
    final diff = (timeFromFactor(c, temp) - targetH).abs();
    if (diff < bestDiff) {
      bestDiff = diff;
      best = c;
    }
  }

  return {'factor': best, 'exact': fExact};
}

/// Erstellt lesbares Verhältnis-Label
String ratioLabel(double f) {
  if (f == 1.0) return '1 / 1 / 1';
  if (f == 1.5) return '1 / 1.5 / 1.5';
  return '1 / ${f.toInt()} / ${f.toInt()}';
}

/// Formatiert Stunden in lesbaren String
String formatH(double h) {
  final hh = h.floor();
  final mm = ((h - hh) * 60).round();
  if (mm == 0) return '${hh}h';
  return '${hh}h ${mm}min';
}

/// Gibt Temperaturfarbe zurück
Color tempColor(double t) {
  if (t <= 10) return AppColors.blue;
  if (t <= 18) return AppColors.green;
  if (t <= 24) return const Color(0xFFCCE850);
  if (t <= 30) return AppColors.orange;
  if (t <= 37) return const Color(0xFFE85030);
  return AppColors.red;
}

// ═══════════════════════════════════════════════════════════════
//  ERGEBNIS-DATENKLASSE
// ═══════════════════════════════════════════════════════════════
class PlanerResult {
  final double temp;
  final double factor;
  final double fExact;
  final String ratio;
  final double estTime;
  final double timeDiff;
  final int anstellgut;
  final int wasser;
  final int mehl;
  final int gesamt;
  final int forRecipe;
  final int leftover;
  final DateTime dFeed;
  final DateTime dHalf;
  final DateTime dPeak;
  final String tempLabel;
  final String tempAdvice;
  final List<String> steps;

  PlanerResult({
    required this.temp,
    required this.factor,
    required this.fExact,
    required this.ratio,
    required this.estTime,
    required this.timeDiff,
    required this.anstellgut,
    required this.wasser,
    required this.mehl,
    required this.gesamt,
    required this.forRecipe,
    required this.leftover,
    required this.dFeed,
    required this.dHalf,
    required this.dPeak,
    required this.tempLabel,
    required this.tempAdvice,
    required this.steps,
  });
}

// ═══════════════════════════════════════════════════════════════
//  HAUPT-SCREEN
// ═══════════════════════════════════════════════════════════════
class PlanerScreen extends StatefulWidget {
  const PlanerScreen({super.key});

  @override
  State<PlanerScreen> createState() => _PlanerScreenState();
}

class _PlanerScreenState extends State<PlanerScreen> {
  // Eingabewerte
  double _temp = 22;
  double _amount = 100;
  double _starter = 20;
  double _hours = 12;
  int _selectedTimeIndex = 3; // "in 12h"

  PlanerResult? _result;

  // Zeit-Buttons
  final List<Map<String, dynamic>> _timeOptions = [
    {'label': 'in 4h',  'h': 4.0},
    {'label': 'in 6h',  'h': 6.0},
    {'label': 'in 8h',  'h': 8.0},
    {'label': 'in 12h', 'h': 12.0},
    {'label': 'in 16h', 'h': 16.0},
    {'label': 'in 24h', 'h': 24.0},
    {'label': 'in 36h', 'h': 36.0},
    {'label': 'individuell', 'h': 0.0},
  ];

  bool _showCustomTime = false;
  final _customController = TextEditingController();

  // ── Berechnen ─────────────────────────────────────────────
  void _calculate() {
    final hours = _hours;
    if (hours <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte Backzeit angeben.')),
      );
      return;
    }

    final best = pickBestFactor(hours, _temp);
    final factor = best['factor'] as double;
    final fExact = best['exact'] as double;
    final estTime = timeFromFactor(factor, _temp);
    final timeDiff = (estTime - hours).abs();
    final ratio = ratioLabel(factor);

    final rA = 1.0, rW = factor, rM = factor;
    final total = rA + rW + rM;
    final target = _amount + _starter * 0.3;

    final anstellgut = (rA / total * target).ceil();
    final wasser     = (rW / total * target).ceil();
    final mehl       = (rM / total * target).ceil();
    final gesamt     = anstellgut + wasser + mehl;
    final forRecipe  = _amount.toInt();
    final leftover   = gesamt - forRecipe;

    final now   = DateTime.now();
    final dFeed = now;
    final dHalf = now.add(Duration(minutes: (estTime * 0.5 * 60).round()));
    final dPeak = now.add(Duration(minutes: (estTime * 60).round()));

    // Temperaturinfo
    String tempLabel, tempAdvice;
    if (_temp <= 6) {
      tempLabel = 'Kühlschrank-Temperatur';
      tempAdvice = 'Extrem langsam. Nur für Pausen geeignet. Starter erst auf Raumtemperatur bringen.';
    } else if (_temp <= 14) {
      tempLabel = 'Sehr kalt';
      tempAdvice = 'Langsam. Starter an wärmeren Ort stellen (Backofen mit Lampe, ~25°C).';
    } else if (_temp <= 20) {
      tempLabel = 'Kühl — kontrollierbar';
      tempAdvice = 'Gute Arbeitstemperatur. Starter entwickelt schönes Aroma.';
    } else if (_temp <= 25) {
      tempLabel = 'Ideal ✓';
      tempAdvice = 'Optimale Bedingungen. Gut vorhersagbar, volles Aroma.';
    } else if (_temp <= 30) {
      tempLabel = 'Warm — beobachten';
      tempAdvice = 'Schnell. Regelmäßig prüfen — Höhepunkt kommt und geht schnell.';
    } else if (_temp <= 35) {
      tempLabel = 'Heiß — Vorsicht';
      tempAdvice = 'Sehr schnell. Kaltes Wasser (8–12°C) nutzen. Gut im Auge behalten.';
    } else if (_temp <= 38) {
      tempLabel = '⚠️ Kritisch heiß';
      tempAdvice = 'Am Limit! Nach dem Füttern sofort in den Kühlschrank (4–6°C). Dort langsam fermentieren lassen.';
    } else {
      tempLabel = '☠️ Zu heiß!';
      tempAdvice = 'Ab 38°C sterben Milchsäurebakterien! Starter SOFORT kühlen. Backen verschieben.';
    }

    // Schritte
    List<String> steps;
    if (_temp >= 38) {
      steps = [
        'Starter sofort kühlen — Glas direkt in den Kühlschrank (4–6°C).',
        'Backen verschieben auf einen kühleren Zeitpunkt (unter 32°C).',
        'Nach dem Abkühlen: 1–2h akklimatisieren, dann mit 1/1/1 und kaltem Wasser füttern.',
        'Float-Test nach Verdopplung. Wenn positiv → normal weitermachen.',
      ];
    } else if (_temp >= 35) {
      steps = [
        'Eiskaltes Wasser (8–10°C) abmessen: ${wasser}g',
        'Mehl: ${mehl}g — Anstellgut: ${anstellgut}g',
        'Verrühren, 15–20 Min. bei Raumtemperatur anspringen lassen, dann sofort in den Kühlschrank',
        'Im Kühlschrank nach ca. ${formatH(estTime * 2.5)}–${formatH(estTime * 3)} prüfen',
        'Nach Verdopplung ${forRecipe}g abnehmen → in den Teig',
        'Restliche ${leftover}g als neues Anstellgut im Kühlschrank aufbewahren',
      ];
    } else if (_temp <= 14) {
      steps = [
        'Wärmeren Ort suchen: Nähe Herd, Backofen mit Lampe (ca. 25°C)',
        'Wasser (leicht warm, max. 30°C): ${wasser}g',
        'Mehl: ${mehl}g — Anstellgut: ${anstellgut}g — verrühren',
        'An den wärmsten Ort stellen und regelmäßig prüfen',
        'Verdopplung abwarten — dauert bei ${_temp.toInt()}°C deutlich länger',
        '${forRecipe}g abnehmen → in den Teig. Rest als neues Anstellgut.',
      ];
    } else {
      steps = [
        'Wasser abmessen (Raumtemperatur): ${wasser}g',
        'Mehl: ${mehl}g + Anstellgut: ${anstellgut}g',
        'Alles in ein sauberes Glas geben und gut verrühren',
        'Glas mit Gummiband bei aktueller Füllhöhe markieren',
        'Bei ca. ${_temp.toInt()}°C stehen lassen — nach ca. ${formatH(estTime)} prüfen',
        'Bei Verdopplung: sofort ${forRecipe}g abnehmen und in den Teig',
        '${leftover}g als neues Anstellgut ${_temp > 28 ? 'sofort in den Kühlschrank' : 'weiterführen oder kühlen'}',
      ];
    }

    setState(() {
      _result = PlanerResult(
        temp: _temp, factor: factor, fExact: fExact, ratio: ratio,
        estTime: estTime, timeDiff: timeDiff,
        anstellgut: anstellgut, wasser: wasser, mehl: mehl,
        gesamt: gesamt, forRecipe: forRecipe, leftover: leftover,
        dFeed: dFeed, dHalf: dHalf, dPeak: dPeak,
        tempLabel: tempLabel, tempAdvice: tempAdvice, steps: steps,
      );
    });

    // Erinnerungen setzen
    _scheduleNotifications(_result!);
  }

  // ── Benachrichtigungen ────────────────────────────────────
  Future<void> _scheduleNotifications(PlanerResult r) async {
    await notifications.cancelAll();

    final androidDetails = const AndroidNotificationDetails(
      'sauerteig', 'Sauerteig Planer',
      channelDescription: 'Erinnerungen für den Sauerteig',
      importance: Importance.high,
      priority: Priority.high,
    );
    final details = NotificationDetails(android: androidDetails);

    final now = DateTime.now();

    Future<void> scheduleAt(int id, DateTime time, String title, String body) async {
      if (time.isAfter(now)) {
        await notifications.schedule(id, title, body, time, details);
      }
    }

    await scheduleAt(1, r.dHalf,
      '🫧 Sauerteig prüfen',
      'Bläschen sichtbar? Noch ${formatH(r.estTime * 0.5)} bis zum Höhepunkt.');

    // 15 Min Vorwarnung vor Peak
    final preWarning = r.dPeak.subtract(const Duration(minutes: 15));
    await scheduleAt(2, preWarning,
      '⏰ Sauerteig fast fertig!',
      'In ~15 Minuten ist der Höhepunkt erreicht. Bereit machen!');

    await scheduleAt(3, r.dPeak,
      '🎯 HÖHEPUNKT — Sauerteig verwenden!',
      '${r.forRecipe}g abnehmen → in den Teig. Float-Test machen!');

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ 3 Erinnerungen gesetzt!'),
        backgroundColor: Color(0xFF1A3020),
      ),
    );
  }

  // ── ICS Export ────────────────────────────────────────────
  Future<void> _exportICS() async {
    final r = _result;
    if (r == null) return;

    String icsDate(DateTime d) =>
        d.toUtc().toIso8601String().replaceAll(RegExp(r'[-:]'), '').replaceAll(RegExp(r'\.\d{3}'), '');

    String makeEvent(DateTime start, DateTime end, String summary, String desc) {
      return 'BEGIN:VEVENT\r\n'
          'UID:${DateTime.now().millisecondsSinceEpoch}@sauerteig\r\n'
          'DTSTART:${icsDate(start)}\r\n'
          'DTEND:${icsDate(end)}\r\n'
          'SUMMARY:$summary\r\n'
          'DESCRIPTION:${desc.replaceAll('\n', '\\n')}\r\n'
          'BEGIN:VALARM\r\nTRIGGER:-PT0M\r\nACTION:DISPLAY\r\nDESCRIPTION:$summary\r\nEND:VALARM\r\n'
          'END:VEVENT\r\n';
    }

    final ics = StringBuffer();
    ics.write('BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Sauerteig Planer//DE\r\n');
    ics.write(makeEvent(r.dFeed, r.dFeed.add(const Duration(minutes: 10)),
        '🍞 Sauerteig füttern',
        'Verhältnis ${r.ratio}\nAnstellgut: ${r.anstellgut}g\nWasser: ${r.wasser}g\nMehl: ${r.mehl}g'));
    ics.write(makeEvent(r.dHalf, r.dHalf.add(const Duration(minutes: 10)),
        '🫧 Erste Aktivität prüfen', 'Bläschen sichtbar?\nNoch ${formatH(r.estTime * 0.5)} bis Höhepunkt.'));
    ics.write(makeEvent(r.dPeak, r.dPeak.add(const Duration(minutes: 15)),
        '🎯 HÖHEPUNKT — jetzt verwenden!',
        '${r.forRecipe}g abnehmen → in den Teig\nFloat-Test machen!\n${r.leftover}g als neues Anstellgut.'));
    ics.write('END:VCALENDAR\r\n');

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/Sauerteig_Zeitplan.ics');
    await file.writeAsString(ics.toString());
    await Share.shareXFiles([XFile(file.path)], text: 'Sauerteig Zeitplan');
  }

  // ── PDF Export ────────────────────────────────────────────
  Future<void> _exportPDF() async {
    final r = _result;
    if (r == null) return;

    final doc = pw.Document();
    final fmt = DateFormat('HH:mm');
    final gold = PdfColor.fromHex('#D4A84B');
    final dark = PdfColors.grey800;

    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(24),
      build: (ctx) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          // Titel
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(16),
            decoration: pw.BoxDecoration(color: PdfColors.grey900),
            child: pw.Text('🍞 Sauerteig Zeitplan',
              style: pw.TextStyle(fontSize: 20, color: gold, fontWeight: pw.FontWeight.bold)),
          ),
          pw.SizedBox(height: 12),

          // Zusammenfassung
          pw.Row(children: [
            _pdfBox('${r.temp.toInt()}°C', 'Temperatur', gold, ctx),
            pw.SizedBox(width: 8),
            _pdfBox(r.ratio, 'Verhältnis', gold, ctx),
            pw.SizedBox(width: 8),
            _pdfBox('~${formatH(r.estTime)}', 'bis Peak', gold, ctx),
          ]),
          pw.SizedBox(height: 16),

          // Rezept
          _pdfSection('REZEPT', gold),
          _pdfRow('Anstellgut', '${r.anstellgut} g', dark),
          _pdfRow('Wasser', '${r.wasser} g', dark),
          _pdfRow('Mehl', '${r.mehl} g', dark),
          _pdfRow('→ ins Rezept', '${r.forRecipe} g', dark, bold: true),
          _pdfRow('→ Anstellgut behalten', '${r.leftover} g', dark),
          pw.SizedBox(height: 12),

          // Zeitplan
          _pdfSection('ZEITPLAN', gold),
          _pdfTimeline(fmt.format(r.dFeed), 'Jetzt — Füttern',
              'Anstellgut ${r.anstellgut}g + Wasser ${r.wasser}g + Mehl ${r.mehl}g', gold),
          _pdfTimeline(fmt.format(r.dHalf), 'Erste Aktivität',
              'Bläschen sichtbar, Starter beginnt zu wachsen', dark),
          _pdfTimeline(fmt.format(r.dPeak), '🎯 HÖHEPUNKT — jetzt verwenden!',
              '${r.forRecipe}g abnehmen → in den Teig. Float-Test!', gold),
          pw.SizedBox(height: 12),

          // Schritte
          _pdfSection('ANLEITUNG', gold),
          ...r.steps.asMap().entries.map((e) =>
            pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 5),
              child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('${e.key + 1}. ', style: pw.TextStyle(color: gold, fontWeight: pw.FontWeight.bold, fontSize: 9)),
                pw.Expanded(child: pw.Text(e.value, style: pw.TextStyle(fontSize: 9, color: dark))),
              ]),
            )
          ),
          pw.SizedBox(height: 12),

          // Temperatur
          _pdfSection('TEMPERATURHINWEIS', gold),
          pw.Text(r.tempLabel, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9, color: dark)),
          pw.SizedBox(height: 4),
          pw.Text(r.tempAdvice, style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
        ],
      ),
    ));

    await Printing.sharePdf(bytes: await doc.save(), filename: 'Sauerteig_Zeitplan.pdf');
  }

  pw.Widget _pdfBox(String val, String lbl, PdfColor gold, pw.Context ctx) =>
    pw.Expanded(child: pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(color: PdfColors.grey200, borderRadius: pw.BorderRadius.circular(4)),
      child: pw.Column(children: [
        pw.Text(val, style: pw.TextStyle(color: gold, fontWeight: pw.FontWeight.bold, fontSize: 13), textAlign: pw.TextAlign.center),
        pw.Text(lbl, style: pw.TextStyle(fontSize: 7, color: PdfColors.grey600), textAlign: pw.TextAlign.center),
      ]),
    ));

  pw.Widget _pdfSection(String title, PdfColor gold) => pw.Container(
    width: double.infinity,
    color: PdfColors.grey200,
    padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    margin: const pw.EdgeInsets.only(bottom: 6),
    child: pw.Text(title, style: pw.TextStyle(color: gold, fontWeight: pw.FontWeight.bold, fontSize: 9)),
  );

  pw.Widget _pdfRow(String label, String val, PdfColor color, {bool bold = false}) =>
    pw.Padding(padding: const pw.EdgeInsets.symmetric(vertical: 2), child:
      pw.Row(children: [
        pw.Expanded(child: pw.Text(label, style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600))),
        pw.Text(val, style: pw.TextStyle(fontSize: 9, color: color, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
      ]));

  pw.Widget _pdfTimeline(String time, String title, String desc, PdfColor color) =>
    pw.Padding(padding: const pw.EdgeInsets.only(bottom: 8), child:
      pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(time, style: pw.TextStyle(color: color, fontWeight: pw.FontWeight.bold, fontSize: 8)),
        pw.SizedBox(width: 10),
        pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Text(title, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9)),
          pw.Text(desc, style: pw.TextStyle(fontSize: 8, color: PdfColors.grey600)),
        ])),
      ]));

  // ═══════════════════════════════════════════════════════════
  //  BUILD UI
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          // Header
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            backgroundColor: const Color(0xFF1A1510),
            flexibleSpace: FlexibleSpaceBar(
              title: const Text('🍞 Sauerteig Planer',
                style: TextStyle(color: AppColors.gold2, fontSize: 16, fontWeight: FontWeight.w600)),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1A1510), AppColors.bg],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── EINGABE-KARTE ──────────────────────────
                _Card(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                    const _SectionTitle('⚙️ Eingabe'),
                    const SizedBox(height: 16),

                    // Temperatur-Slider
                    const _FieldLabel('Raumtemperatur'),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.surface2,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(children: [
                        Text('${_temp.toInt()}°C',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: tempColor(_temp),
                          )),
                        const SizedBox(height: 6),
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: tempColor(_temp),
                            thumbColor: AppColors.gold,
                            inactiveTrackColor: AppColors.surface3,
                            overlayColor: AppColors.gold.withOpacity(0.2),
                          ),
                          child: Slider(
                            value: _temp, min: 4, max: 42,
                            divisions: 38,
                            onChanged: (v) => setState(() => _temp = v),
                          ),
                        ),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Text('4°C ❄️', style: TextStyle(color: AppColors.text3, fontSize: 11)),
                            Text('22°C ✓', style: TextStyle(color: AppColors.text3, fontSize: 11)),
                            Text('42°C 🔥', style: TextStyle(color: AppColors.text3, fontSize: 11)),
                          ]),
                      ]),
                    ),
                    const SizedBox(height: 14),

                    // Mengen
                    Row(children: [
                      Expanded(child: _NumInput(
                        label: 'Sauerteig benötigt',
                        unit: 'g',
                        value: _amount,
                        onChanged: (v) => setState(() => _amount = v),
                      )),
                      const SizedBox(width: 12),
                      Expanded(child: _NumInput(
                        label: 'Anstellgut vorhanden',
                        unit: 'g',
                        value: _starter,
                        onChanged: (v) => setState(() => _starter = v),
                      )),
                    ]),
                    const SizedBox(height: 14),

                    // Zeit-Buttons
                    const _FieldLabel('Wann willst du backen?'),
                    GridView.count(
                      crossAxisCount: 4, shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 7, crossAxisSpacing: 7,
                      childAspectRatio: 2.2,
                      children: _timeOptions.asMap().entries.map((e) {
                        final i = e.key; final opt = e.value;
                        final active = i == _selectedTimeIndex;
                        return GestureDetector(
                          onTap: () => setState(() {
                            _selectedTimeIndex = i;
                            if (opt['h'] == 0.0) {
                              _showCustomTime = true;
                            } else {
                              _showCustomTime = false;
                              _hours = opt['h'];
                            }
                          }),
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: active ? const Color(0xFF2A2210) : AppColors.surface2,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: active ? AppColors.gold : AppColors.border,
                              ),
                            ),
                            child: Text(opt['label'],
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 11,
                                color: active ? AppColors.gold : AppColors.text2,
                              )),
                          ),
                        );
                      }).toList(),
                    ),

                    if (_showCustomTime) ...[
                      const SizedBox(height: 10),
                      _NumInput(
                        label: 'In wie vielen Stunden?',
                        unit: 'h',
                        value: _hours,
                        onChanged: (v) => setState(() => _hours = v),
                      ),
                    ],

                    const SizedBox(height: 18),

                    // Berechnen-Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _calculate,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2A1E08),
                          foregroundColor: AppColors.gold2,
                          side: const BorderSide(color: AppColors.goldDim),
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('🧮 Anleitung berechnen',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ]),
                ),

                const SizedBox(height: 16),

                // ── ERGEBNIS ─────────────────────────────────
                if (_result != null) ...[
                  _ResultView(result: _result!, onExportICS: _exportICS, onExportPDF: _exportPDF),
                ] else ...[
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(vertical: 40),
                    child: const Column(children: [
                      Text('🌾', style: TextStyle(fontSize: 40)),
                      SizedBox(height: 10),
                      Text('Eingaben ausfüllen und\nBerechnen tippen',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.text3, fontSize: 14)),
                    ]),
                  ),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  ERGEBNIS-WIDGET
// ═══════════════════════════════════════════════════════════════
class _ResultView extends StatelessWidget {
  final PlanerResult result;
  final VoidCallback onExportICS;
  final VoidCallback onExportPDF;

  const _ResultView({required this.result, required this.onExportICS, required this.onExportPDF});

  @override
  Widget build(BuildContext context) {
    final r = result;
    final fmt = DateFormat('HH:mm');
    final timeDiffStr = formatH(r.timeDiff);

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      // ── ZUSAMMENFASSUNG ──────────────────────────────────
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle('📊 Zusammenfassung'),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _SummaryBox(value: '${r.temp.toInt()}°C', label: r.tempLabel, color: tempColor(r.temp))),
          const SizedBox(width: 8),
          Expanded(child: _SummaryBox(value: r.ratio, label: 'Verhältnis', color: AppColors.gold2)),
          const SizedBox(width: 8),
          Expanded(child: _SummaryBox(value: '~${formatH(r.estTime)}', label: 'bis Peak', color: AppColors.text)),
        ]),
        if (r.fExact != r.factor) ...[
          const SizedBox(height: 10),
          _InfoBox(
            color: AppColors.blue,
            bgColor: const Color(0xFF0E1820),
            text: '🔢 Exaktes Verhältnis: 1 / ${r.fExact.toStringAsFixed(1)} / ${r.fExact.toStringAsFixed(1)}'
                ' → gerundet auf ${r.ratio} (±$timeDiffStr)',
          ),
        ],
        const SizedBox(height: 14),
        // Tabelle
        _RecipeTable(r: r),
      ])),

      const SizedBox(height: 12),

      // ── ZEITPLAN ─────────────────────────────────────────
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle('🕐 Zeitplan'),
        const SizedBox(height: 14),
        _TimelineItem(
          time: '${fmt.format(r.dFeed)} — Jetzt',
          title: 'Füttern',
          desc: 'Anstellgut ${r.anstellgut}g + Wasser ${r.wasser}g + Mehl ${r.mehl}g verrühren. Höhe markieren.',
          isNow: true,
        ),
        _TimelineItem(
          time: '${fmt.format(r.dHalf)} (+${formatH(r.estTime * 0.5)})',
          title: 'Erste Aktivität',
          desc: 'Bläschen sichtbar, Starter beginnt zu wachsen.',
        ),
        _TimelineItem(
          time: '${fmt.format(r.dPeak)} (+${formatH(r.estTime)}) 🎯',
          title: 'Höhepunkt — jetzt verwenden!',
          desc: 'Verdoppelt. ${r.forRecipe}g abnehmen → in den Teig. Float-Test!',
          isHighlight: true,
        ),
        _TimelineItem(
          time: 'danach',
          title: 'Rest wegstellen',
          desc: '${r.leftover}g als neues Anstellgut. ${r.temp > 28 ? 'Sofort in den Kühlschrank.' : 'Kühlschrank oder weiterführen.'}',
        ),
        const SizedBox(height: 10),
        _InfoBox(
          color: AppColors.green,
          bgColor: const Color(0xFF0E2018),
          text: '🧪 Float-Test: 1 TL Starter ins Wasser — schwimmt er? → Bereit ✅   Sinkt er? → Noch warten.',
        ),
      ])),

      const SizedBox(height: 12),

      // ── SCHRITTE ─────────────────────────────────────────
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle('📋 Schritt-für-Schritt'),
        const SizedBox(height: 12),
        ...r.steps.asMap().entries.map((e) => _StepItem(index: e.key + 1, text: e.value)),
      ])),

      const SizedBox(height: 12),

      // ── TEMPERATURHINWEISE ────────────────────────────────
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _SectionTitle('🌡️ Temperaturhinweise'),
        const SizedBox(height: 10),
        Text(r.tempAdvice, style: const TextStyle(color: AppColors.text2, fontSize: 14, height: 1.6)),
        const Divider(color: AppColors.border, height: 24),
        const _TempLegend(),
      ])),

      const SizedBox(height: 16),

      // ── EXPORT ───────────────────────────────────────────
      Row(children: [
        Expanded(child: _ExportButton(
          icon: '📅',
          label: 'Kalender\n(.ics)',
          color: AppColors.blue,
          onTap: onExportICS,
        )),
        const SizedBox(width: 10),
        Expanded(child: _ExportButton(
          icon: '📑',
          label: 'PDF\nexportieren',
          color: AppColors.gold,
          onTap: onExportPDF,
        )),
      ]),

      const SizedBox(height: 40),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
//  KLEINE WIEDERVERWENDBARE WIDGETS
// ═══════════════════════════════════════════════════════════════

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    ),
    child: child,
  );
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
    style: const TextStyle(fontFamily: 'serif', fontSize: 16,
        fontWeight: FontWeight.bold, color: AppColors.gold));
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 7),
    child: Text(text.toUpperCase(),
      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
          color: AppColors.text2, letterSpacing: 0.8)),
  );
}

class _NumInput extends StatelessWidget {
  final String label, unit;
  final double value;
  final void Function(double) onChanged;
  const _NumInput({required this.label, required this.unit, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _FieldLabel(label),
      TextFormField(
        initialValue: value.toInt().toString(),
        keyboardType: TextInputType.number,
        style: const TextStyle(fontFamily: 'monospace', fontSize: 18, color: AppColors.text),
        decoration: InputDecoration(
          suffixText: unit,
          suffixStyle: const TextStyle(color: AppColors.text3, fontSize: 13),
          filled: true,
          fillColor: AppColors.surface2,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: AppColors.goldDim),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
        onChanged: (v) { final parsed = double.tryParse(v); if (parsed != null) onChanged(parsed); },
      ),
    ],
  );
}

class _SummaryBox extends StatelessWidget {
  final String value, label;
  final Color color;
  const _SummaryBox({required this.value, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
    decoration: BoxDecoration(
      color: AppColors.surface2,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(children: [
      Text(value, textAlign: TextAlign.center,
        style: TextStyle(fontFamily: 'monospace', fontSize: 16,
            fontWeight: FontWeight.bold, color: color)),
      const SizedBox(height: 4),
      Text(label, textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 10, color: AppColors.text3)),
    ]),
  );
}

class _RecipeTable extends StatelessWidget {
  final PlanerResult r;
  const _RecipeTable({required this.r});
  @override
  Widget build(BuildContext context) => Table(
    columnWidths: const {0: FlexColumnWidth(2), 1: FlexColumnWidth(1), 2: FlexColumnWidth(2)},
    children: [
      _tableHeader(),
      _tableRow('Anstellgut', '${r.anstellgut} g', 'aus vorhandenem Starter'),
      _tableRow('Wasser', '${r.wasser} g',
          r.temp >= 35 ? '❄️ eiskaltes Wasser' : r.temp >= 28 ? 'kühles Wasser' : 'Raumtemperatur'),
      _tableRow('Mehl', '${r.mehl} g', 'Weizen 550 oder Roggen'),
      _tableRowBold('Gesamt', '${r.gesamt} g', ''),
      _tableRowGreen('→ ins Rezept', '${r.forRecipe} g', 'nach Verdopplung'),
      _tableRow('→ behalten', '${r.leftover} g', 'neues Anstellgut'),
    ],
  );

  TableRow _tableHeader() => TableRow(children: [
    'Zutat', 'Menge', 'Hinweis'
  ].map((t) => Padding(padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
    child: Text(t, style: const TextStyle(fontSize: 10, color: AppColors.text3, letterSpacing: 0.5)))).toList());

  TableRow _tableRow(String a, String b, String c) => TableRow(children: [
    _cell(a, AppColors.text2), _cell(b, AppColors.gold2, mono: true), _cell(c, AppColors.text3, small: true),
  ]);
  TableRow _tableRowBold(String a, String b, String c) => TableRow(children: [
    _cell(a, AppColors.text, bold: true), _cell(b, AppColors.text, mono: true), _cell(c, AppColors.text3),
  ]);
  TableRow _tableRowGreen(String a, String b, String c) => TableRow(children: [
    _cell(a, AppColors.text2), _cell(b, AppColors.green, mono: true), _cell(c, AppColors.text3, small: true),
  ]);

  Widget _cell(String t, Color c, {bool mono=false, bool bold=false, bool small=false}) =>
    Padding(padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 4),
      child: Text(t, style: TextStyle(
        fontFamily: mono ? 'monospace' : null,
        fontSize: small ? 11 : 13,
        color: c,
        fontWeight: bold ? FontWeight.bold : FontWeight.normal,
      )));
}

class _TimelineItem extends StatelessWidget {
  final String time, title, desc;
  final bool isNow, isHighlight;
  const _TimelineItem({required this.time, required this.title, required this.desc,
    this.isNow = false, this.isHighlight = false});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: isHighlight ? const EdgeInsets.all(10) : EdgeInsets.zero,
    decoration: isHighlight ? BoxDecoration(
      color: const Color(0xFF1E1C10),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: AppColors.goldDim),
    ) : null,
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        width: 10, height: 10, margin: const EdgeInsets.only(top: 4, right: 12),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isNow ? AppColors.gold : Colors.transparent,
          border: Border.all(color: isNow ? AppColors.gold : AppColors.goldDim, width: 2),
          boxShadow: isNow ? [BoxShadow(color: AppColors.gold.withOpacity(0.5), blurRadius: 6)] : null,
        ),
      ),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(time, style: TextStyle(
          fontFamily: 'monospace', fontSize: 13, fontWeight: FontWeight.bold,
          color: isHighlight ? AppColors.gold2 : AppColors.gold)),
        const SizedBox(height: 2),
        Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.text)),
        const SizedBox(height: 2),
        Text(desc, style: const TextStyle(fontSize: 12, color: AppColors.text2, height: 1.5)),
      ])),
    ]),
  );
}

class _StepItem extends StatelessWidget {
  final int index;
  final String text;
  const _StepItem({required this.index, required this.text});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        width: 24, height: 24,
        margin: const EdgeInsets.only(right: 12, top: 1),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.surface3,
          border: Border.all(color: AppColors.border),
        ),
        child: Center(child: Text('$index',
          style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: AppColors.gold))),
      ),
      Expanded(child: Text(text,
        style: const TextStyle(fontSize: 13, color: AppColors.text2, height: 1.6))),
    ]),
  );
}

class _InfoBox extends StatelessWidget {
  final Color color, bgColor;
  final String text;
  const _InfoBox({required this.color, required this.bgColor, required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    margin: const EdgeInsets.only(top: 4),
    decoration: BoxDecoration(
      color: bgColor,
      borderRadius: BorderRadius.circular(8),
      border: Border(left: BorderSide(color: color, width: 3)),
    ),
    child: Text(text, style: TextStyle(fontSize: 12.5, color: color, height: 1.6)),
  );
}

class _TempLegend extends StatelessWidget {
  const _TempLegend();
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: const [
      _LegendRow('❄️ Kühlschrank (4–6°C):', '1–2 Wochen, 1× pro Woche füttern', AppColors.blue),
      _LegendRow('🌿 18–24°C:', 'Ideal — gut vorhersagbar', AppColors.green),
      _LegendRow('🌡️ 28–32°C:', 'Schnell — aufmerksam beobachten', Color(0xFFE8C050)),
      _LegendRow('🔥 35°C+:', 'Eiskaltes Wasser + Kühlschrank-Strategie', AppColors.orange),
      _LegendRow('☠️ 38°C+:', 'Bakterien sterben — sofort kühlen!', AppColors.red),
    ],
  );
}

class _LegendRow extends StatelessWidget {
  final String label, desc;
  final Color color;
  const _LegendRow(this.label, this.desc, this.color);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 5),
    child: RichText(text: TextSpan(children: [
      TextSpan(text: '$label ', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
      TextSpan(text: desc, style: const TextStyle(color: AppColors.text3, fontSize: 12)),
    ])),
  );
}

class _ExportButton extends StatelessWidget {
  final String icon, label;
  final Color color;
  final VoidCallback onTap;
  const _ExportButton({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.6)),
      ),
      child: Column(children: [
        Text(icon, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: 4),
        Text(label, textAlign: TextAlign.center,
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600, height: 1.3)),
      ]),
    ),
  );
}

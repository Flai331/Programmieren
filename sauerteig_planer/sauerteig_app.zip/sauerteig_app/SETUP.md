# 🍞 Sauerteig Planer — Android App Setup

## Was du brauchst (alles kostenlos)
- Windows / Mac / Linux PC
- Android-Handy mit USB-Kabel

---

## Schritt 1 — Flutter installieren

1. Gehe auf: https://docs.flutter.dev/get-started/install/windows
2. Lade das Flutter SDK herunter (ZIP-Datei)
3. Entpacke die ZIP nach `C:\flutter`
4. Öffne Windows-Einstellungen → "Umgebungsvariablen"
5. Unter "Path" → Neu → `C:\flutter\bin` hinzufügen
6. PC neu starten

**Test:** Öffne CMD und tippe:
```
flutter doctor
```
Du siehst was noch fehlt.

---

## Schritt 2 — Android Studio installieren

1. Gehe auf: https://developer.android.com/studio
2. Installieren, starten
3. Beim ersten Start: "Android SDK" installieren lassen (dauert ~10 Min)
4. In Flutter Doctor prüfen: `flutter doctor --android-licenses`
   → Alle Fragen mit `y` bestätigen

---

## Schritt 3 — Projekt einrichten

1. Öffne CMD im Ordner `sauerteig_app`
2. Tippe:
```
flutter pub get
```
Das installiert alle benötigten Pakete (share_plus, pdf, etc.)

---

## Schritt 4 — App auf Handy testen

### Handy vorbereiten:
1. Android-Einstellungen → "Über das Telefon"
2. 7× auf "Build-Nummer" tippen → "Entwickleroptionen" erscheinen
3. Entwickleroptionen → "USB-Debugging" einschalten
4. Handy per USB an PC anschließen
5. "Dateien übertragen" auswählen

### App starten:
```
flutter run
```
→ Wähle dein Handy aus der Liste
→ App wird automatisch gebaut und gestartet (dauert beim ersten Mal ~2 Min)

---

## Schritt 5 — APK bauen (für Installation ohne PC)

```
flutter build apk --release
```

Die fertige APK liegt dann unter:
```
build/app/outputs/flutter-apk/app-release.apk
```

Diese APK kannst du per WhatsApp, E-Mail oder USB auf jedes Android-Handy schicken und installieren.

**Hinweis:** Beim ersten Installieren muss "Unbekannte Quellen" in den Android-Einstellungen erlaubt werden.

---

## Dateien-Übersicht

```
sauerteig_app/
├── lib/
│   └── main.dart          ← Die gesamte App (Logik + UI)
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml  ← Android-Berechtigungen
├── pubspec.yaml           ← Pakete / Abhängigkeiten
└── SETUP.md               ← Diese Anleitung
```

---

## Häufige Fehler

| Problem | Lösung |
|---|---|
| `flutter: command not found` | PATH-Variable prüfen, PC neu starten |
| `No devices found` | USB-Debugging einschalten, Kabel tauschen |
| `Gradle build failed` | `flutter clean` → `flutter pub get` → nochmal |
| App öffnet sich nicht | APK neu bauen: `flutter build apk --release` |

---

## Nächste Schritte (optional)

Wenn du mehr lernen willst:
- **Flutter Docs:** https://docs.flutter.dev
- **Dart Grundlagen:** https://dart.dev/guides
- **YouTube:** "Flutter für Anfänger" (viele gute deutsche Videos)

Die App ist bewusst in **einer Datei** (main.dart) gehalten — 
so kannst du den gesamten Code auf einmal sehen und verstehen.
